#include <stdio.h>

void print_hello();

int main(int argc, char *argv[]) {
    print_hello();
    return 0;
}

void print_hello() {
    printf("Hello, world!\n");
}
