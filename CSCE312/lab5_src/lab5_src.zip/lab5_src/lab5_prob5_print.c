#include <stdio.h>

void print_hello() {
    printf("Hello, world!\n");
}
